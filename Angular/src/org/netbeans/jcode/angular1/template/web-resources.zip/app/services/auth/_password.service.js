(function() {
    'use strict';

    angular
        .module('<%= angularAppName %>')
        .factory('Password', Password);

    Password.$inject = ['$resource'];

    function Password($resource) {
        var service = $resource(<% if(authenticationType === 'uaa') { %>'<%= uaaBaseName.toLowerCase() %>/<%= applicationPath %>/api/account/change-password'<%} else { %>'<%= applicationPath %>/api/account/change-password'<% } %>, {}, {});

        return service;
    }
})();
