<%#
 Copyright 2013-2018 the original author or authors from the JHipster project.

 This file is part of the JHipster project, see http://www.jhipster.tech/
 for more information.

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
-%>
import * as React from 'react';
import { Route, Switch } from 'react-router-dom';
import { ModalRoute } from 'react-router-modal';

import <%= entityReactName %> from './<%= entityFileName %>';
import <%= entityReactName %>Detail from './<%= entityFileName %>-detail';
import <%= entityReactName %>Dialog from './<%= entityFileName %>-dialog';
import <%= entityReactName %>DeleteDialog from './<%= entityFileName %>-delete-dialog';

const Routes = ({ match }) => (
  <div>
    <Switch>
      <Route exact path={match.url} component={<%= entityReactName %>} />
      <ModalRoute exact parentPath={match.url} path={`${match.url}/new`} component={<%= entityReactName %>Dialog} />
      <ModalRoute exact parentPath={match.url} path={`${match.url}/:id/delete`} component={<%= entityReactName %>DeleteDialog} />
      <ModalRoute exact parentPath={match.url} path={`${match.url}/:id/edit`} component={<%= entityReactName %>Dialog} />
      <Route exact path={`${match.url}/:id`} component={<%= entityReactName %>Detail} />
    </Switch>
  </div>
);

export default Routes;
