
import * as React from 'react';
import { Route, Switch } from 'react-router-dom';
import { ModalRoute } from 'react-router-modal';

import UserManagement from './user-management';
import UserManagementDetail from './user-management-detail';
import UserManagementDialog from './user-management-dialog';
import UserManagementDeleteDialog from './user-management-delete-dialog';

const Routes = ({ match }) => (
  <div>
    <Switch>
      <Route exact path={match.url} component={UserManagement} />
      <ModalRoute exact parentPath={match.url} path={`${match.url}/new`} component={UserManagementDialog} />
      <ModalRoute exact parentPath={match.url} path={`${match.url}/:login/delete`} component={UserManagementDeleteDialog} />
      <ModalRoute exact parentPath={match.url} path={`${match.url}/:login/edit`} component={UserManagementDialog} />
      <Route exact path={`${match.url}/:login`} component={UserManagementDetail} />
    </Switch>
  </div>
);

export default Routes;
